package baseclasses;

import interfaces.IClassroom;

/**
 * Use this class to create Classrooms. Each classroom should contain a
 * room number and room type.
 *
 * Room types can be any of the following from the enumerated list below:
 * 1) Lab 
 * 2) Classroom 
 * 3) Lecture Hall
 *
 */
public class Classroom implements IClassroom {

    private String roomNumber;
    private String typeOfRoom;

    // Default no-arg constructor, assume some default values
    public Classroom() {
        roomNumber = "000";
        typeOfRoom = "CLASSROOM";
    }

    // Overloaded constructor
    public Classroom(String number, String typeOfRoom) {
        this.roomNumber = number;
        this.typeOfRoom = typeOfRoom;
    }

    public String getRoomNumber() {
        return this.roomNumber;
    }

    public String getTypeOfRoom() {
        return typeOfRoom;
    }

    public void setRoomNumber(String room) {
        this.roomNumber = room;
    }

    public void setTypeOfRoom(String typeOfRoom) {
        this.typeOfRoom = typeOfRoom;
    }

    @Override
    public String toString() {
        return "Classroom{" + "roomNumber=" + roomNumber + ", typeOfRoom=" + typeOfRoom + '}';
    }   

}
