/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package baseclasses;
import java.util.GregorianCalendar;
import java.util.ArrayList;

/**
 *
 * @author Magister
 */
public class Faculty extends Person {
    private GregorianCalendar dateOfHire;
    private GregorianCalendar dateOfTermination;

    @Override
    public String toString() {
        return "Faculty{" + "dateOfHire=" + dateOfHire + ", dateOfTermination=" + dateOfTermination + ", status=" + 
                status + ", salary=" + salary + ", listOfCourses=" + listOfCourses + '}';
    }
    private String status;
    private double salary;
    private ArrayList<Faculty> listOfCourses;

    public GregorianCalendar getDateOfHire() {
        return dateOfHire;
    }

    public void setDateOfHire(GregorianCalendar dateOfHire) {
        this.dateOfHire = dateOfHire;
    }

    public GregorianCalendar getDateOfTermination() {
        return dateOfTermination;
    }

    public void setDateOfTermination(GregorianCalendar dateOfTermination) {
        this.dateOfTermination = dateOfTermination;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public ArrayList<Faculty> getListOfCourses() {
        return listOfCourses;
    }

    public void setListOfCourses(ArrayList<Faculty> listOfCourses) {
        this.listOfCourses = listOfCourses;
    }

}
