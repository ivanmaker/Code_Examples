/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package baseclasses;

import interfaces.ICourse;

/**
 *
 * @author Magister
 */
public class OfferedCourse implements ICourse {
    public OfferedCourse (){      
    }
    private Classroom classroom;
    private String courseName, courseId;

    

    @Override
    public String toString() {
        return "OfferedCourse{" + "classroom=" + classroom + ", coursName=" + courseName + ", courseId=" + courseId + '}';
    }
    public Classroom getClassroom() {
        return classroom;
    }
    public void setClassroom(Classroom classroom) {
        this.classroom = classroom;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseId() {
        return courseId;
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }
            
}
