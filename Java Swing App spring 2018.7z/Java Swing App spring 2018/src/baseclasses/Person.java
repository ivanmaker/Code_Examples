/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package baseclasses;

import interfaces.IPerson;
import java.util.GregorianCalendar;
/**
 *
 * @author Magister
 */
public class Person implements IPerson {

    @Override
    public String toString() {
        return "Person{" + "name=" + name + ", address=" + address + ", socialSecurityNumber=" +
            socialSecurityNumber + ", dateOfBirth=" + dateOfBirth + '}';
    }
    private String name, address;
    private String socialSecurityNumber;

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String getAddress() {
        return address;
    }

    @Override
    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String getSocialSecurityNumber() {
        return socialSecurityNumber;
    }

    @Override
    public void setSocialSecurityNumber(String socialSecurityNumber) {
        this.socialSecurityNumber = socialSecurityNumber;
    }

    @Override
    public GregorianCalendar getDateOfBirth() {
        return dateOfBirth;
    }

    @Override
    public void setDateOfBirth(GregorianCalendar dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }
    //.format("%9.9s");
    private GregorianCalendar dateOfBirth;
}
