/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package baseclasses;
import java.util.GregorianCalendar;
import java.util.ArrayList;

/**
 *
 * @author Magister
 */
public class Student extends Person {
    private float currentGPA;
    private GregorianCalendar dateOfGraduation;
    private ArrayList<StudentCourse> enrolledCourses;

   

    @Override
    public String toString() {
        return "Student{" + "currentGPA=" + currentGPA + ", dateOfGraduation=" + dateOfGraduation + ", enrolledCourses=" + enrolledCourses + '}';
    }
    public float getCurrentGPA() {
        return currentGPA;
    }
    
    public void setCurrentGPA(float currentGPA) {
        this.currentGPA = currentGPA;
    }

    public GregorianCalendar getDateOfGraduation() {
        return dateOfGraduation;
    }

    public void setDateOfGraduation(GregorianCalendar dateOfGraduation) {
        this.dateOfGraduation = dateOfGraduation;
    }

    public ArrayList<StudentCourse> getEnrolledCourses() {
        return enrolledCourses;
    }

    public void setEnrolledCourses(ArrayList<StudentCourse> enrolledCourses) {
        this.enrolledCourses = enrolledCourses;
    }
    
}
