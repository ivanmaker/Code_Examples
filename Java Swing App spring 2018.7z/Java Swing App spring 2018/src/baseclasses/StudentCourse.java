/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package baseclasses;

import interfaces.ICourse;
import java.util.ArrayList;

/**
 *
 * @author Magister
 */
public class StudentCourse implements ICourse {
    private String courseId;
    private ArrayList<Float> courseGrades;

    public String getCourseId() {
        return courseId;
    }

    @Override
    public String toString() {
        return "StudentCourse{" + "courseId=" + courseId + ", courseGrades=" + courseGrades + '}';
    }

    public void setCourseId(String courseId) {
        this.courseId = courseId;
    }

    public ArrayList<Float> getCourseGrades() {
        return courseGrades;
    }

    public void setCourseGrades(ArrayList<Float> courseGrades) {
        this.courseGrades = courseGrades;
    }
}
