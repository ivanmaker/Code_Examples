/*
 * This is the main entry into the application. It creates a menu controller object
 * and the controller object creates the forms and the data models
 */
package controller;

public class Application {

    public static void main(String[] args) {
        MainMenuController controller = new MainMenuController();
    }
}
