/*
 * Handles all events on the classroom report form
 */
package controller;

import java.awt.event.ActionListener;
import model.ClassroomDataModel;
import view.ClassroomReportForm;

public class ClassroomReportFormController implements ActionListener {

     // The Classroom data model is passed in via the constructor
    ClassroomDataModel dataModel;
    
    // The form is created new
    ClassroomReportForm form;

    // Constructor 
    public ClassroomReportFormController(ClassroomDataModel dataModel) {
        this.dataModel = dataModel;
        form = new ClassroomReportForm(this);
    }

    /**
     * Implements actionPerformed method of the ActionListener interface
     */
    public void actionPerformed(java.awt.event.ActionEvent event) {

        //  Figure out which button was clicked
        String buttonClicked = event.getActionCommand();

        if (buttonClicked.equals("Close")) {
            form.dispose();
        }
    }
    
    // get/set methods

    public ClassroomDataModel getDataModel() {
        return dataModel;
    }

    public ClassroomReportForm getForm() {
        return form;
    }
    

}
