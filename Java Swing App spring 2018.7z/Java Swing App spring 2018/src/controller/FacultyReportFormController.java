/*
 * Handles all events on the classroom report form
 */
package controller;

import java.awt.event.ActionListener;
import model.FacultyDataModel;
import view.FacultyReportForm;

public class FacultyReportFormController implements ActionListener {

     // The Classroom data model is passed in via the constructor
    FacultyDataModel dataModel;
    
    // The form is created new
    FacultyReportForm form;

    // Constructor 
    public FacultyReportFormController(FacultyDataModel dataModel) {
        this.dataModel = dataModel;
        form = new FacultyReportForm(this);
    }

    /**
     * Implements actionPerformed method of the ActionListener interface
     * @param event
     */
    @Override
    public void actionPerformed(java.awt.event.ActionEvent event) {

        //  Figure out which button was clicked
        String buttonClicked = event.getActionCommand();

        if (buttonClicked.equals("Close")) {
            form.dispose();
        }
    }
    
    // get/set methods

    public FacultyDataModel getDataModel() {
        return dataModel;
    }

    public FacultyReportForm getForm() {
        return form;
    }
    

}
