/*
 * Listens for events on the input form. 
 * Implements the ActionListener interface which contains a single method, 
 * "actionPerformed"
 */
package controller;

import baseclasses.Classroom;
import exceptionclasses.ErrorDialog;
import exceptionclasses.NoDataException;
import java.awt.event.ActionListener;
import javax.swing.ComboBoxModel;
import model.ClassroomDataModel;
import view.ClassroomInputForm;

public class InputClassroomFormController implements ActionListener {

    // The Classroom data model is passed in via the constructor
    ClassroomDataModel dataModel;

    // The form is created new
    ClassroomInputForm form;

    // Constructor 
    public InputClassroomFormController(ClassroomDataModel dataModel) {
        this.dataModel = dataModel;
        form = new ClassroomInputForm(this);
    }

    /**
     * Implements actionPerformed method of the ActionListener interface
     */
    public void actionPerformed(java.awt.event.ActionEvent event) {

        //  Figure out which button was clicked
        String buttonClicked = event.getActionCommand();

        if (buttonClicked.equals("Save")) {

            try {

                // Create a new classroom object
                Classroom aClassroom = new Classroom();

                // Retrieve the values from the form
                String room = form.getRoomNumberTextfield().getText();

                // Throw an exception if room is empty
                if (room.length() == 0) {
                    throw new NoDataException("Room number is blank");
                }

                // The value must come from the drop down list of room types
                // Step 1 - Retrieve the data model associated with the combo list box
                ComboBoxModel datamodel = this.form.getRoomTypeCombobox().getModel();
                // Step 2 - Retrieve the selected item from the data model
                Object selectedItem = datamodel.getSelectedItem();
                // Step 3 - Convert (Cast) the selected item to a string
                String roomType = (String) selectedItem;
                // Step 4 - Use the Classroom setters to set the values
                aClassroom.setRoomNumber(room);
                aClassroom.setTypeOfRoom(roomType);

                // Add to the new classroom to the list in ClassroomDataModel
                dataModel.getListOfClassrooms().add(aClassroom);

            } catch (NoDataException error) {
                ErrorDialog errordialog = new ErrorDialog(error.getMessage());
                errordialog.setVisible(true);
            }

        } else if (buttonClicked.equals("Clear")) {
            // Reset the fields
            form.getRoomNumberTextfield().setText("");
            form.getRoomTypeCombobox().setSelectedIndex(0);
        } else if (buttonClicked.equals("Close")) {
            // Close and dispose of the form
            form.dispose();
        }
    }

}
