/*
 * Listens for events on the input form. 
 * Implements the ActionListener interface which contains a single method, 
 * "actionPerformed"
 */
package controller;

import baseclasses.Faculty;
import baseclasses.FacultyCourse;
import exceptionclasses.ErrorDialog;
import exceptionclasses.InvalidDataException;
import exceptionclasses.NoDataException;
import java.awt.event.ActionListener;
import java.util.GregorianCalendar;
import model.FacultyDataModel;
import view.FacultyInputForm;

public class InputFacultyFormController implements ActionListener {

    // The Classroom data model is passed in via the constructor
    FacultyDataModel dataModel;

    // The form is created new
    FacultyInputForm form;
    
    // Constructor 
    public InputFacultyFormController(FacultyDataModel dataModel) {
        this.dataModel = dataModel;
        form = new FacultyInputForm(this);
    }

    /**
     * Implements actionPerformed method of the ActionListener interface
     * @param event
     */
    @Override
    public void actionPerformed(java.awt.event.ActionEvent event) {

        //  Figure out which button was clicked
        String buttonClicked = event.getActionCommand();

        if (buttonClicked.equals("Save")) {

            try {

                // Create a new classroom object
                Faculty aFaculty = new Faculty();
                FacultyCourse aFacultyCourse = new FacultyCourse();
                
                String nameTextfield = form.getnameTextfield().getText();
                if (nameTextfield.length() == 0) {
                    throw new NoDataException("Name is blank");
                }
                aFaculty.setName(nameTextfield);
         
                String DOBYearTextfield = form.getDOBYearTextfield().getText();
                String DOBMonthTextfield = form.getDOBMonthTextfield().getText();
                String DOBDayTextfield = form.getDOBDayTextfield().getText();
                
                StringBuilder dateOFBirth = new StringBuilder();
                dateOFBirth.append(DOBYearTextfield);
                dateOFBirth.append(DOBMonthTextfield);
                dateOFBirth.append(DOBDayTextfield);           
                String DOBTextfield = dateOFBirth.toString();
                
                if (DOBTextfield.length() == 0) {
                    throw new NoDataException("Date of Birth is blank");
                }
                
                int BirthMonth = Integer.parseInt(DOBMonthTextfield);
                int BirthDay = Integer.parseInt(DOBDayTextfield);
                int BirthYear = Integer.parseInt(DOBYearTextfield);
                
                GregorianCalendar DOB = new GregorianCalendar(BirthYear, BirthMonth, BirthDay);
                aFaculty.setDateOfBirth(DOB);
                
                String socialSecurityNumberTextfield = form.getsocialSecurityNumberTextfield().getText();
                if (!socialSecurityNumberTextfield.matches("[0-9]+") ) {
                    throw new InvalidDataException("Social Security Number is incorrect");
                }
                if (socialSecurityNumberTextfield.length() != 9) {
                    throw new NoDataException("Social Security Number is Blank");
                }
                aFaculty.setSocialSecurityNumber(socialSecurityNumberTextfield);
                
                String addressTextfield = form.getaddressTextfield().getText();
                if (addressTextfield.length() == 0) {
                    throw new NoDataException("Address is blank");
                }
                aFaculty.setAddress(addressTextfield);
                
                String DOHYearTextfield = form.getDOHYearTextfield().getText();
                String DOHMonthTextfield = form.getDOHMonthTextfield().getText();
                String DOHDayTextfield = form.getDOHDayTextfield().getText();
                
                StringBuilder dateOFHire = new StringBuilder();
                dateOFHire.append(DOBYearTextfield);
                dateOFHire.append(DOBMonthTextfield);
                dateOFHire.append(DOBDayTextfield);           
                String DOHTextfield = dateOFHire.toString();
                
                if (DOHTextfield.length() == 0) {
                    throw new NoDataException("Date of Hire is blank");
                }
                
                int HireMonth = Integer.parseInt(DOHMonthTextfield);
                int HireDay = Integer.parseInt(DOHDayTextfield);
                int HireYear = Integer.parseInt(DOHYearTextfield);
                
                GregorianCalendar DOH = new GregorianCalendar(HireYear, HireMonth, HireDay);
                aFaculty.setDateOfHire(DOH);
                
                String DOTYearTextfield = form.getDOTYearTextfield().getText();
                String DOTMonthTextfield = form.getDOTMonthTextfield().getText();
                String DOTDayTextfield = form.getDOTDayTextfield().getText();
                
                StringBuilder dateOFDOTMonthTextfield = new StringBuilder();
                dateOFDOTMonthTextfield.append(DOTYearTextfield);
                dateOFDOTMonthTextfield.append(DOTMonthTextfield);
                dateOFDOTMonthTextfield.append(DOTDayTextfield);           
                String DOTTextfield = dateOFDOTMonthTextfield.toString();
                
                if (DOTTextfield.length() == 0) {
                    throw new NoDataException("Date of Termination is blank");
                }
                
                int TerminationMonth = Integer.parseInt(DOTMonthTextfield);
                int TerminationDay = Integer.parseInt(DOTDayTextfield);
                int TerminationYear = Integer.parseInt(DOTYearTextfield);
                
                GregorianCalendar DOT = new GregorianCalendar(TerminationYear, TerminationMonth, TerminationDay);
                aFaculty.setDateOfHire(DOT);
                
                String courseIDTextfield = form.getcourseIDTextfield().getText();
                if (courseIDTextfield.length() == 0) {
                    throw new NoDataException("Course ID is blank");
                }
                aFacultyCourse.setCourseId(courseIDTextfield);
                
                String salaryTextfield = form.getsalaryTextfield().getText();
                double d = Double.parseDouble(salaryTextfield);
                if (salaryTextfield.length() == 0) {
                    throw new NoDataException("Salary is Blank");
                }
                if (!salaryTextfield.matches("[0-9]+")) {
                    throw new InvalidDataException("Salary is incorrect");
                }
                aFaculty.setSalary(d);
                
                String statusTextfield = form.getstatusTextfield().getText();
                if (statusTextfield.length() == 0) {
                    throw new NoDataException("Status is incorrect");
                }
                aFaculty.setStatus(statusTextfield);
                
                dataModel.getlistOfFaculty().add(aFaculty);
                dataModel.getlistOfFacultyCourse().add(aFacultyCourse);
                
            } catch (NoDataException error) {
                ErrorDialog errordialog = new ErrorDialog(error.getMessage());
                errordialog.setVisible(true);
            } catch (InvalidDataException error) {
                ErrorDialog errordialog = new ErrorDialog(error.getMessage());
                errordialog.setVisible(true);
            }

        } else if (buttonClicked.equals("Clear")) {
            // Reset the fields
            form.getnameTextfield().setText("");           
            form.getDOBYearTextfield().setText("");
            form.getDOBMonthTextfield().setText("");
            form.getDOBDayTextfield().setText("");
            form.getaddressTextfield().setText("");          
            form.getDOHYearTextfield().setText("");
            form.getDOHMonthTextfield().setText("");
            form.getDOHDayTextfield().setText("");
            form.getDOTYearTextfield().setText("");
            form.getDOTMonthTextfield().setText("");
            form.getDOTDayTextfield().setText("");
            form.getcourseIDTextfield().setText("");
            form.getsalaryTextfield().setText("");            
            form.getstatusTextfield().setText("");
            
        } else if (buttonClicked.equals("Close")) {
            // Close and dispose of the form
            form.dispose();
        }
    }

}
