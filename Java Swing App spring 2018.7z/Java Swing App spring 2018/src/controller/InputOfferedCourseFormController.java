/*
 * Listens for events on the input form. 
 * Implements the ActionListener interface which contains a single method, 
 * "actionPerformed"
 */
package controller;

import baseclasses.Classroom;
import baseclasses.OfferedCourse;
import exceptionclasses.ErrorDialog;
import exceptionclasses.NoDataException;
import java.awt.event.ActionListener;
import model.OfferedCourseDataModel;
import view.OfferedCourseInputForm;

public class InputOfferedCourseFormController implements ActionListener {

    // The Classroom data model is passed in via the constructor
    OfferedCourseDataModel dataModel;

    // The form is created new
    OfferedCourseInputForm form;

    // Constructor 
    public InputOfferedCourseFormController(OfferedCourseDataModel dataModel) {
        this.dataModel = dataModel;
        form = new OfferedCourseInputForm(this);
    }

    /**
     * Implements actionPerformed method of the ActionListener interface
     * @param event
     */
    @Override
    public void actionPerformed(java.awt.event.ActionEvent event) {

        //  Figure out which button was clicked
        String buttonClicked = event.getActionCommand();

        if (buttonClicked.equals("Save")) {

            try {

                // Create a new classroom object
                OfferedCourse aOfferedCourse = new OfferedCourse();

                String courseIDTextfield = form.getcourseIDTextfield().getText();
                if (courseIDTextfield.length() == 0) {
                    throw new NoDataException("Course ID is blank");
                }
                aOfferedCourse.setCourseId(courseIDTextfield);
                
                String roomTypeTextfield = form.getroomTypeTextfield().getText();
                String roomNumberTextfield = form.getroomNumberTextfield().getText();
               
                StringBuilder classroomBuilder = new StringBuilder();
                classroomBuilder.append(roomTypeTextfield);
                classroomBuilder.append(roomNumberTextfield);      
                String classroomTextfield = classroomBuilder.toString();
                               
                if (classroomTextfield.length() == 0) {
                    throw new NoDataException("Classroom is blank");
                }
                Classroom classroom = new Classroom(roomTypeTextfield, roomNumberTextfield);
                aOfferedCourse.setClassroom(classroom);
                
                String classNameTextfield = form.getclassNameTextfield().getText();
                if (classNameTextfield.length() == 0) {
                    throw new NoDataException("ClassName is blank");
                }
                aOfferedCourse.setCourseName(classNameTextfield);
               
                // Add to the new classroom to the list in ClassroomDataModel
                dataModel.getListOfOfferedCourses().add(aOfferedCourse);

            } catch (NoDataException error) {
                ErrorDialog errordialog = new ErrorDialog(error.getMessage());
                errordialog.setVisible(true);
            }

        } else if (buttonClicked.equals("Clear")) {
            // Reset the fields
           
            form.getcourseIDTextfield().setText("");
            form.getroomTypeTextfield().setText("");
            form.getroomNumberTextfield().setText("");
            form.getclassNameTextfield().setText("");
           
        } else if (buttonClicked.equals("Close")) {
            // Close and dispose of the form
            form.dispose();
        }
    }

}
