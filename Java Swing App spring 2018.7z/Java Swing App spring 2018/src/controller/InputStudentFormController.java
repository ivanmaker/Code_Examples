/*
 * Listens for events on the input form. 
 * Implements the ActionListener interface which contains a single method, 
 * "actionPerformed"
 */
package controller;

import baseclasses.Student;
import baseclasses.StudentCourse;
import exceptionclasses.ErrorDialog;
import exceptionclasses.InvalidDataException;
import exceptionclasses.NoDataException;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import model.StudentDataModel;
import view.StudentInputForm;

public class InputStudentFormController implements ActionListener {

    // The Classroom data model is passed in via the constructor
    StudentDataModel dataModel;

    // The form is created new
    StudentInputForm form;

    // Constructor 
    public InputStudentFormController(StudentDataModel dataModel) {
        this.dataModel = dataModel;
        form = new StudentInputForm(this);
    }

    /**
     * Implements actionPerformed method of the ActionListener interface
     */
    public void actionPerformed(java.awt.event.ActionEvent event) {

        //  Figure out which button was clicked
        String buttonClicked = event.getActionCommand();

        if (buttonClicked.equals("Save")) {

            try {

                // Create a new classroom object
                Student aStudent = new Student();
                StudentCourse aStudentCourse = new StudentCourse();

                // Retrieve the values from the form
                String nameTextfield = form.getnameTextfield().getText();         
                if (nameTextfield.length() == 0) {
                    throw new NoDataException("Name is blank");
                }
                aStudent.setName(nameTextfield);
                
                String DOBYearTextfield = form.getDOBYearTextfield().getText();
                String DOBMonthTextfield = form.getDOBMonthTextfield().getText();
                String DOBDayTextfield = form.getDOBDayTextfield().getText();
                
                StringBuilder dateOFBirth = new StringBuilder();
                dateOFBirth.append(DOBYearTextfield);
                dateOFBirth.append(DOBMonthTextfield);
                dateOFBirth.append(DOBDayTextfield);           
                String DOBTextfield = dateOFBirth.toString();
                
                if (DOBTextfield.length() == 0) {
                    throw new NoDataException("Date of Birth is blank");
                }
                
                int BirthMonth = Integer.parseInt(DOBMonthTextfield);
                int BirthDay = Integer.parseInt(DOBDayTextfield);
                int BirthYear = Integer.parseInt(DOBYearTextfield);
                
                GregorianCalendar DOB = new GregorianCalendar(BirthYear, BirthMonth, BirthDay);
                aStudent.setDateOfBirth(DOB);
                
                String socialSecurityNumberTextfield = form.getsocialSecurityNumberTextfield().getText();
                if (socialSecurityNumberTextfield.length() != 9) {
                    throw new NoDataException("Social Security Number is Blank");
                }
                if (!socialSecurityNumberTextfield.matches("[0-9]+") ) {
                    throw new InvalidDataException("Social Security Number is incorrect");
                }
                aStudent.setSocialSecurityNumber(socialSecurityNumberTextfield);
                
                String addressTextfield = form.getaddressTextfield().getText();
                if (addressTextfield.length() == 0) {
                    throw new NoDataException("Address is blank");
                }
                
                String GPATextfield = form.getGPATextfield().getText();
                float f = Float.parseFloat(GPATextfield);
                if (GPATextfield.length() == 0) {
                    throw new NoDataException("Current GPA is blank");
                }
                aStudent.setCurrentGPA(f);
                
                String DOGYearTextfield = form.getDOGYearTextfield().getText();
                String DOGMonthTextfield = form.getDOGMonthTextfield().getText();
                String DOGDayTextfield = form.getDOGDayTextfield().getText();
                
                StringBuilder dateOFGraduation = new StringBuilder();
                dateOFGraduation.append(DOGYearTextfield);
                dateOFGraduation.append(DOGMonthTextfield);
                dateOFGraduation.append(DOGDayTextfield);           
                String DOGTextfield = dateOFGraduation.toString();
                
                if (DOGTextfield.length() == 0) {
                    throw new NoDataException("Date of Graduation is blank");
                }
                
                int GraduationMonth = Integer.parseInt(DOGMonthTextfield);
                int GraduationDay = Integer.parseInt(DOGDayTextfield);
                int GraduationYear = Integer.parseInt(DOGYearTextfield);
                
                GregorianCalendar DOG = new GregorianCalendar(GraduationYear, GraduationMonth, GraduationDay);
                aStudent.setDateOfBirth(DOG);
                
                String courseIDTextfield = form.getcourseIDTextfield().getText();
                if (courseIDTextfield.length() == 0) {
                    throw new NoDataException("Course ID is blank");
                }
                aStudentCourse.setCourseId(courseIDTextfield);
             
                String gradesTextfield = form.getgradesTextfield().getText();
                int gradesFloat = Integer.parseInt(gradesTextfield);
                ArrayList<Float> gradesArray = new ArrayList<Float>(gradesFloat);
                if (gradesTextfield.length() == 0) {
                    throw new NoDataException("Grades is blank");
                }
                aStudentCourse.setCourseGrades(gradesArray);
                
                dataModel.getListOfStudents().add(aStudent);
                dataModel.getListOfStudentsCourse().add(aStudentCourse);
                               
            } catch (NoDataException error) {
                ErrorDialog errordialog = new ErrorDialog(error.getMessage());
                errordialog.setVisible(true);
                
            } catch (InvalidDataException error) {
                ErrorDialog errordialog = new ErrorDialog(error.getMessage());
                errordialog.setVisible(true);
            }

        } else if (buttonClicked.equals("Clear")) {
            // Reset the fields
            form.getnameTextfield().setText("");           
            form.getDOBYearTextfield().setText("");
            form.getDOBMonthTextfield().setText("");
            form.getDOBDayTextfield().setText("");
            form.getaddressTextfield().setText("");            
            form.getGPATextfield().setText("");
            form.getDOGYearTextfield().setText("");
            form.getDOGMonthTextfield().setText("");
            form.getDOGDayTextfield().setText("");
            form.getcourseIDTextfield().setText("");
            form.getgradesTextfield().setText("");
            
        } else if (buttonClicked.equals("Close")) {
            // Close and dispose of the form
            form.dispose();
        }
    }

}
