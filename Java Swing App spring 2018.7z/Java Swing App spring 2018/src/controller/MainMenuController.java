/*
 * Controller class for the top level menu form
 */

package controller;

import java.awt.event.ActionListener;
import model.ClassroomDataModel;
import model.FacultyDataModel;
import model.OfferedCourseDataModel;
import model.StudentDataModel;
import utilities.ClassroomIO;
import utilities.FacultyIO;
import utilities.OfferedCourseIO;
import utilities.StudentIO;
import view.MainMenu;

public class MainMenuController implements ActionListener {
    
    // The Classroom data model which gets created here and passed to the 
    // constructors for the input and report controllers
    ClassroomDataModel classroomDataModel = new ClassroomDataModel();
    StudentDataModel studentDataModel = new StudentDataModel();
    FacultyDataModel facultyDataModel = new FacultyDataModel();
    OfferedCourseDataModel offeredCourseDataModel = new OfferedCourseDataModel();
    
    // The Classroom controllers which get created here and passed to the 
    // constructors for the input and report forms
    //InputClassroomFormController inputController = new InputClassroomFormController(classroomDataModel);
    
    MainMenu mainMenu = new MainMenu(this);
    
           
     /**
     * ActionListener actionPerformed method implemented
     * @param event
     */
    @Override
    public void actionPerformed(java.awt.event.ActionEvent event) {

        //  Figure out which button was clicked
        String menuItemClicked = event.getActionCommand();

        // create the controller which will open the form
        if (menuItemClicked.equals("List Classrooms")) {
            ClassroomReportFormController reportController = new ClassroomReportFormController(classroomDataModel);            
        } else if (menuItemClicked.equals("Add Classroom")) {
            InputClassroomFormController inputController = new InputClassroomFormController(classroomDataModel);               
        } else if (menuItemClicked.equals("Save Data")) {
            ClassroomIO.writeSerializedFile(classroomDataModel);
            ClassroomIO.writeTextFile(classroomDataModel);
            ClassroomIO.writeXMLFile(classroomDataModel);
            ClassroomIO.writeJSONFile(classroomDataModel);
        } else if (menuItemClicked.equals("Read Data")) {
            classroomDataModel.setListOfClassrooms(ClassroomIO.readSerializedFile());
            classroomDataModel.setListOfClassrooms(ClassroomIO.readTextFile());
            classroomDataModel.setListOfClassrooms(ClassroomIO.readXMLFile());
            classroomDataModel.setListOfClassrooms(ClassroomIO.readJSONFile());
        }
        
        if (menuItemClicked.equals("Report")) {
            StudentReportFormController reportController = new StudentReportFormController(studentDataModel);            
        } else if (menuItemClicked.equals("Add Student")) {
            InputStudentFormController inputController = new InputStudentFormController(studentDataModel);               
        } else if (menuItemClicked.equals("Save Data")) {
            StudentIO.writeSerializedFile(studentDataModel);
            StudentIO.writeTextFile(studentDataModel);
            StudentIO.writeXMLFile(studentDataModel);
            StudentIO.writeJSONFile(studentDataModel);
        } else if (menuItemClicked.equals("Read Data")) {
            studentDataModel.setListOfStudents(StudentIO.readSerializedFile());
            studentDataModel.setListOfStudentsCourse(StudentIO.readSerializedFileStudentCourse());
            studentDataModel.setListOfStudents(StudentIO.readTextFile());
            studentDataModel.setListOfStudentsCourse(StudentIO.readTextFileStudentCourse());
            studentDataModel.setListOfStudents(StudentIO.readXMLFile());
            studentDataModel.setListOfStudentsCourse(StudentIO.readXMLFileStudentCourse());
            studentDataModel.setListOfStudents(StudentIO.readJSONFile());
            studentDataModel.setListOfStudentsCourse(StudentIO.readJSONFileStudentCourse());
        }
        
        if (menuItemClicked.equals("Report")) {
            FacultyReportFormController reportController = new FacultyReportFormController(facultyDataModel);            
        } else if (menuItemClicked.equals("Add Faculty")) {
            InputFacultyFormController inputController = new InputFacultyFormController(facultyDataModel);               
        } else if (menuItemClicked.equals("Save Data")) {
            FacultyIO.writeSerializedFile(facultyDataModel);
            FacultyIO.writeTextFile(facultyDataModel);
            FacultyIO.writeXMLFile(facultyDataModel);
            FacultyIO.writeJSONFile(facultyDataModel);
        } else if (menuItemClicked.equals("Read Data")) {
            facultyDataModel.setlistOfFaculty(FacultyIO.readSerializedFile());
            facultyDataModel.setlistOfFacultyCourse(FacultyIO.readSerializedFileFacultyCourse());
            facultyDataModel.setlistOfFaculty(FacultyIO.readTextFile());
            facultyDataModel.setlistOfFacultyCourse(FacultyIO.readTextFileFacultyCourse());
            facultyDataModel.setlistOfFaculty(FacultyIO.readXMLFile());
            facultyDataModel.setlistOfFacultyCourse(FacultyIO.readXMLFileFacultyCourse());
            facultyDataModel.setlistOfFaculty(FacultyIO.readJSONFile());
            facultyDataModel.setlistOfFacultyCourse(FacultyIO.readJSONFileFacultyCourse());
        }
        
        if (menuItemClicked.equals("Report")) {
            OfferedCourseReportFormController reportController = new OfferedCourseReportFormController(offeredCourseDataModel);            
        } else if (menuItemClicked.equals("Add Offered Course")) {
            InputOfferedCourseFormController inputController = new InputOfferedCourseFormController(offeredCourseDataModel);               
        } else if (menuItemClicked.equals("Save Data")) {
            OfferedCourseIO.writeSerializedFile(offeredCourseDataModel);
            OfferedCourseIO.writeTextFile(offeredCourseDataModel);
            OfferedCourseIO.writeXMLFile(offeredCourseDataModel);
            OfferedCourseIO.writeJSONFile(offeredCourseDataModel);
        } else if (menuItemClicked.equals("Read Data")) {
            offeredCourseDataModel.setListOfOfferedCourses(OfferedCourseIO.readSerializedFile());
            offeredCourseDataModel.setListOfOfferedCourses(OfferedCourseIO.readTextFile());
            offeredCourseDataModel.setListOfOfferedCourses(OfferedCourseIO.readXMLFile());
            offeredCourseDataModel.setListOfOfferedCourses(OfferedCourseIO.readJSONFile());
        }
    }    
}
