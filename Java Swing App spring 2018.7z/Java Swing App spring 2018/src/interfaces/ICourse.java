/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfaces;

/**
 *
 * @author Magister
 */
public interface ICourse {
    public void setCourseId(String courseId);   
    public String getCourseId();

    /**
     *
     * @return
     */
    @Override
    public String toString();
}
