/*
 *  This Class contains a list which will hold classroom objects created in the UI
 */
package model;

import baseclasses.Faculty;
import baseclasses.FacultyCourse;
import java.util.ArrayList;

public class FacultyDataModel {

    private ArrayList<Faculty> listOfFaculty = new ArrayList<Faculty>();
    private ArrayList<FacultyCourse> listOfFacultyCourse = new ArrayList<FacultyCourse>();

    /**
     * no-arg constructor
     */
    public FacultyDataModel() {
    }

    public ArrayList<Faculty> getlistOfFaculty() {
        return listOfFaculty;
    }

    public void setlistOfFaculty(ArrayList<Faculty> listOfFaculty) {
        this.listOfFaculty = listOfFaculty;
    }
    
    public ArrayList<FacultyCourse> getlistOfFacultyCourse() {
        return listOfFacultyCourse;
    }

    public void setlistOfFacultyCourse(ArrayList<FacultyCourse> listOfFacultyCourse) {
        this.listOfFacultyCourse = listOfFacultyCourse;
    }
    
}
