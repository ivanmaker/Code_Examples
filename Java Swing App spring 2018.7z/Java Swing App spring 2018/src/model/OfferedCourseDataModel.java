package model;

import baseclasses.OfferedCourse;

import java.util.ArrayList;

public class OfferedCourseDataModel {

    private ArrayList<OfferedCourse> listOfOfferedCourses = new ArrayList<OfferedCourse>();

    /**
     * no-arg constructor
     */
    public OfferedCourseDataModel() {
    }

    public ArrayList<OfferedCourse> getListOfOfferedCourses() {
        return listOfOfferedCourses;
    }

    public void setListOfOfferedCourses(ArrayList<OfferedCourse> listOfOfferedCourses) {
        this.listOfOfferedCourses = listOfOfferedCourses;
    }
    
}
