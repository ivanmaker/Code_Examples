/*
 *  This Class contains a list which will hold classroom objects created in the UI
 */
package model;

import baseclasses.Student;
import baseclasses.StudentCourse;

import java.util.ArrayList;

public class StudentDataModel {

    private ArrayList<Student> listOfStudents = new ArrayList<Student>();
    private ArrayList<StudentCourse> listOfStudentsCourse = new ArrayList<StudentCourse>();

    /**
     * no-arg constructor
     */
    public StudentDataModel() {
    }

    public ArrayList<Student> getListOfStudents() {
        return listOfStudents;
    }

    public void setListOfStudents(ArrayList<Student> listOfStudents) {
        this.listOfStudents = listOfStudents;
    }
    
    public ArrayList<StudentCourse> getListOfStudentsCourse() {
        return listOfStudentsCourse;
    }

    public void setListOfStudentsCourse(ArrayList<StudentCourse> listOfStudentsCourse) {
        this.listOfStudentsCourse = listOfStudentsCourse;
    }
    
}
