/*
 *  This Class contains lists which will hold objects created in the UI
 *  Anytime you want to store lists of objects created in the UI, add it to
 *  this class.
 */
package utilities;

import baseclasses.Faculty;
import baseclasses.FacultyCourse;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sun.org.apache.xml.internal.serialize.OutputFormat;
import com.sun.org.apache.xml.internal.serialize.XMLSerializer;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import model.FacultyDataModel;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

/**
 * Utility class to read and write Classroom data
 *
 * @author EKRAMER
 */
public class FacultyIO {

    /**
     * Constructor is declared private because the IO classes are utilities
     * which contain static methods
     */
    private FacultyIO() {
    }

    /**
     * Writes out a text file containing all classrooms in the classroom data
     * model
     *
     * The format of the text file is:
     *
     * Example: FA301:CLASSROOM
     */
    public static void writeTextFile(FacultyDataModel facultydatamodel) {

        PrintWriter textFile = null;

        try {
            // Create output file
            textFile = new PrintWriter("faculty.txt");

            // Loop through the array list of classrooms and print delimited text to a file
            for (Faculty faculty : facultydatamodel.getlistOfFaculty()) {
                textFile.println(faculty.getName() + ":" + faculty.getAddress() + ":" + faculty.getDateOfBirth()
                + ":" + faculty.getSocialSecurityNumber() + ":" + faculty.getDateOfTermination() + ":" + faculty.getDateOfHire()
                + ":" + faculty.getSalary() + ":" + faculty.getStatus());
            }
             for (FacultyCourse facultyCourse : facultydatamodel.getlistOfFacultyCourse()) {
                textFile.println(facultyCourse.getCourseId());
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        } finally {
            // Flush the output stream and close the file
            textFile.flush();
            textFile.close();
        }
    }

    /**
     * Creates a serialized object output file containing all classrooms in the
     * classroom data model
     */
    public static void writeSerializedFile(FacultyDataModel facultydatamodel) {
        try {
            // Create output file
            ObjectOutputStream serializedFile = new ObjectOutputStream(
                    new FileOutputStream("faculty.ser"));
            // Write out the data
            serializedFile.writeObject(facultydatamodel.getlistOfFaculty());
            serializedFile.writeObject(facultydatamodel.getlistOfFacultyCourse());
        } catch (Exception exp) {
            Logger.logError(exp.getMessage());
        }
    }

    /**
     * Writes out the classroom data in XML format containing all classrooms in
     * the classroom data model
     */
    public static void writeXMLFile(FacultyDataModel facultydatamodel) {

        // get a document builder factory
        DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();

        try {
            // get a document builder from the factory
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();

            // create an instance of the document model
            Document doc = docBuilder.newDocument();

            // create the root element <list_of_classrooms> and append to document
            Element root = doc.createElement("list_of_faculty");
            doc.appendChild(root);

            // Loop through the array list of classrooms and create the classroom elements of the xml file
            for (Faculty faculty : facultydatamodel.getlistOfFaculty()) {

                Element facultyElement = doc.createElement("faculty");

                Element nameElement = doc.createElement("name");
                Text nameText = doc.createTextNode(faculty.getName());
                nameElement.appendChild(nameText);
                facultyElement.appendChild(nameElement);

                Element addressElement = doc.createElement("address");
                Text addressText = doc.createTextNode(faculty.getAddress());
                addressElement.appendChild(addressText);
                facultyElement.appendChild(addressElement);
                
                Element dateOfBirthElement = doc.createElement("dateOfBirth");
                SimpleDateFormat Formatter = new SimpleDateFormat("yyyy MM dd");   // lowercase "dd"
                dateOfBirthElement.appendChild(doc.createTextNode(Formatter.format(
                faculty.getDateOfBirth().getTime() )));
                facultyElement.appendChild(dateOfBirthElement);
                
                Element dateOfHireElement = doc.createElement("dateOfHire");               
                dateOfHireElement.appendChild(doc.createTextNode(Formatter.format(
                faculty.getDateOfHire().getTime() )));
                facultyElement.appendChild(dateOfHireElement);
                
                Element dateOfTerminationElement = doc.createElement("dateOfTermination");              
                dateOfTerminationElement.appendChild(doc.createTextNode(Formatter.format(
                faculty.getDateOfTermination().getTime() )));
                facultyElement.appendChild(dateOfTerminationElement);
               
                Element socialSecurityNumberElement = doc.createElement("socialSecurityNumber");
                Text socialSecurityNumberText = doc.createTextNode(faculty.getSocialSecurityNumber());
                socialSecurityNumberElement.appendChild(socialSecurityNumberText);
                facultyElement.appendChild(socialSecurityNumberElement);
                
                Element salaryElement = doc.createElement("salary");
                String sal = Double.toString(faculty.getSalary());
                Text salaryText = doc.createTextNode(sal);
                salaryElement.appendChild(salaryText);
                facultyElement.appendChild(salaryElement);
                
                Element statusElement = doc.createElement("status");
                Text statusText = doc.createTextNode(faculty.getStatus());
                statusElement.appendChild(statusText);
                facultyElement.appendChild(statusElement);

                root.appendChild(facultyElement);

            }
            
            for (FacultyCourse facultyCourse : facultydatamodel.getlistOfFacultyCourse()) {

                Element facultyCourseElement = doc.createElement("faculty");

                Element courseIDElement = doc.createElement("courseID");
                Text courseIDText = doc.createTextNode(facultyCourse.getCourseId());
                courseIDElement.appendChild(courseIDText);
                facultyCourseElement.appendChild(courseIDElement);

                root.appendChild(facultyCourseElement);

            }

            // use default xml formatting in the file
            OutputFormat format = new OutputFormat(doc);
            format.setIndenting(true);

            // open the output stream
            XMLSerializer serializer = new XMLSerializer(
                    new FileOutputStream(new File("classroom.xml")), format);

            // write out the object
            serializer.serialize(doc);

        } catch (Exception exp) {
            Logger.logError(exp.getMessage());
        }
    }

    /**
     * Writes out the classroom data in JSON format containing all classrooms in
     * the classroom data model
     *
     */
    public static void writeJSONFile(FacultyDataModel facultydatamodel) {

        PrintWriter jsonFile = null;

        try {
            // Create output file
            jsonFile = new PrintWriter("faculty.json");

            // Create JSON object
            Gson gson = new GsonBuilder().create();

            // Convert classroom list to JSON format
            gson.toJson(facultydatamodel.getlistOfFaculty(), jsonFile);
            gson.toJson(facultydatamodel.getlistOfFacultyCourse(), jsonFile);

        } catch (Exception exp) {
            Logger.logError(exp.getMessage());
        } finally {
            // Flush the output stream and close the file
            jsonFile.flush();
            jsonFile.close();
        }
    }

    /**
     * Reads a set of classroom objects from a serialized file and returns an
     * array list of classrooms
     */
    public static ArrayList<Faculty> readSerializedFile() {

        ArrayList<Faculty> listOfFaculty = new ArrayList<>();

        try {
            ObjectInputStream serializedFile = new ObjectInputStream(
                    new FileInputStream("faculty.ser"));
            // Read the serialized object and cast to its original type
            listOfFaculty = (ArrayList<Faculty>) serializedFile.readObject();
        } catch (Exception exp) {
            Logger.logError(exp.getMessage());
        } finally {
            return listOfFaculty;
        }
    }
    
    public static ArrayList<FacultyCourse> readSerializedFileFacultyCourse() {

        ArrayList<FacultyCourse> listOfFacultyCourse = new ArrayList<>();

        try {
            ObjectInputStream serializedFile = new ObjectInputStream(
                    new FileInputStream("faculty.ser"));
            // Read the serialized object and cast to its original type
            listOfFacultyCourse = (ArrayList<FacultyCourse>) serializedFile.readObject();
        } catch (Exception exp) {
            Logger.logError(exp.getMessage());
        } finally {
            return listOfFacultyCourse;
        }
    }

    /**
     * Reads a delimited text file of classrooms and returns an array list of
     * classrooms.
     *
     * eof is used to keep track of whether we hit the end of the file, It
     * starts out false and if we hit the end of file (null input), it changes
     * to true and execution stops.
     *
     * The format of the text file is:
     *
     * Example: FA301:CLASSROOM
     */
    public static ArrayList<Faculty> readTextFile() {

        ArrayList<Faculty> listOfFaculty = new ArrayList<>();

        try {
            boolean eof = false;
            BufferedReader textFile = new BufferedReader(new FileReader("faculty.txt"));
            while (!eof) {
                String lineFromFile = textFile.readLine();
                if (lineFromFile == null) {
                    eof = true;
                } else {
                    // Create a classroom
                    Faculty faculty = new Faculty();

                    String[] lineElements = lineFromFile.split(":");
                    // The first element is the classroom number
                    faculty.setName(lineElements[0]);
                    // The second element is the classroom type
                    faculty.setAddress(lineElements[1]);
                    
                    DateFormat df = new SimpleDateFormat("dd MM yyyy");
                    Date DOB = df.parse(lineElements[2]);                  
                    Calendar DOBcal = new GregorianCalendar();
                    DOBcal.setTime(DOB);
                    faculty.setDateOfBirth((GregorianCalendar) DOBcal);
                    
                    Date DOH = df.parse(lineElements[3]);                  
                    Calendar DOHcal = new GregorianCalendar();
                    DOHcal.setTime(DOH);
                    faculty.setDateOfHire((GregorianCalendar) DOHcal);
                    
                    Date DOT = df.parse(lineElements[4]);                  
                    Calendar DOTcal = new GregorianCalendar();
                    DOTcal.setTime(DOT);
                    faculty.setDateOfTermination((GregorianCalendar) DOTcal);
                    
                    faculty.setSocialSecurityNumber(lineElements[5]);
                    
                    Double sal = Double.parseDouble(lineElements[5]);
                    faculty.setSalary(sal);
                    
                    listOfFaculty.add(faculty);
                }
            }
        } catch (Exception exp) {
            Logger.logError(exp.getMessage());
        } finally {
            return listOfFaculty;
        }
    }
    
     public static ArrayList<FacultyCourse> readTextFileFacultyCourse() {

        ArrayList<FacultyCourse> listOfFacultyCourse = new ArrayList<>();

        try {
            boolean eof = false;
            BufferedReader textFile = new BufferedReader(new FileReader("faculty.txt"));
            while (!eof) {
                String lineFromFile = textFile.readLine();
                if (lineFromFile == null) {
                    eof = true;
                } else {
                    // Create a classroom
                    FacultyCourse facultyCourse = new FacultyCourse();

                    String[] lineElements = lineFromFile.split(":");
                    // The first element is the classroom number
                    facultyCourse.setCourseId(lineElements[0]);
                    // The second element is the classroom type                   
                    listOfFacultyCourse.add(facultyCourse);
                }
            }
        } catch (Exception exp) {
            Logger.logError(exp.getMessage());
        } finally {
            return listOfFacultyCourse;
        }
    }

    /**
     * Reads an XML formatted file of classrooms and returns an array list of
     * classrooms
     */
    public static ArrayList<Faculty> readXMLFile() {

        ArrayList<Faculty> listOfFaculty = new ArrayList<>();

        try {
            // Get the factory instance
            DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
            //Using factory, get an instance of document builder
            DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
            //parse using builder to get document representation of the XML file
            Document xmlDocument = documentBuilder.parse("faculty.xml");
            //get the root elememt (list_of_classrooms)
            Element list_of_faculty = xmlDocument.getDocumentElement();
            //retrieve the list of classrooms from the root of the document
            NodeList facultyList = list_of_faculty.getElementsByTagName("faculty");
            //loop through the list of classrooms and create classroom objects            
            for (int i = 0; i < facultyList.getLength(); i++) {
                //get a classroom element from the list
                Element facultyElement = (Element) facultyList.item(i);
                //get the data for the classroom, we retrieve node lists for convenience
                //but we will only have one of each so we will use the first element in 
                // each list
                NodeList nameList = facultyElement.getElementsByTagName("name");
                NodeList addressList = facultyElement.getElementsByTagName("address");
                NodeList DOBList = facultyElement.getElementsByTagName("dateOfBirth");
                NodeList DOHList = facultyElement.getElementsByTagName("dateOfHire");
                NodeList DOTList = facultyElement.getElementsByTagName("dateOfTermination");
                NodeList SSNList = facultyElement.getElementsByTagName("socialSecurityNumber");
                NodeList salaryList = facultyElement.getElementsByTagName("salary");
                NodeList statusList = facultyElement.getElementsByTagName("status");
                //create a classroom
                Faculty newFaculty = new Faculty();
                //retrieve the first element from the roomnumber list and get its content (text value)
                String name = nameList.item(0).getTextContent();
                //set the value in the classroom
                newFaculty.setName(name);
                //retrieve the first element from the roomtype list and get its content (text value)
                String address = addressList.item(0).getTextContent();
                //compare this string to the values in the RoomType class and set the correct value
                newFaculty.setAddress(address); 
                
                String DOBString = DOBList.item(0).getTextContent();                
                DateFormat df = new SimpleDateFormat("dd MM yyyy");
                Date DOB = df.parse(DOBString);                  
                Calendar DOBcal = new GregorianCalendar();
                DOBcal.setTime(DOB);               
                newFaculty.setDateOfBirth((GregorianCalendar) DOBcal);
                
                String DOHString = DOHList.item(0).getTextContent();                                
                Date DOH = df.parse(DOHString);                  
                Calendar DOHcal = new GregorianCalendar();
                DOHcal.setTime(DOH);               
                newFaculty.setDateOfHire((GregorianCalendar) DOHcal);
                
                String DOTString = DOTList.item(0).getTextContent();                
                Date DOT = df.parse(DOTString);                  
                Calendar DOTcal = new GregorianCalendar();
                DOTcal.setTime(DOT);               
                newFaculty.setDateOfTermination((GregorianCalendar) DOTcal);
                
                String SSN = SSNList.item(0).getTextContent();               
                newFaculty.setSocialSecurityNumber(SSN);
                
                String salary = salaryList.item(0).getTextContent();  
                Double sal = Double.parseDouble(salary);  
                newFaculty.setSalary(sal);
                
                String status = statusList.item(0).getTextContent();               
                newFaculty.setStatus(status);
                
                //add the classroom to the data model arraylist
                listOfFaculty.add(newFaculty);
            }
        } // if wrong file name is entered, let Main Menu handle it
        catch (Exception exp) {
            Logger.logError(exp.getMessage());
        } finally {
            return listOfFaculty;
        }
    }

    public static ArrayList<FacultyCourse> readXMLFileFacultyCourse() {

        ArrayList<FacultyCourse> listOfFacultyCourse = new ArrayList<>();

        try {
            // Get the factory instance
            DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
            //Using factory, get an instance of document builder
            DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
            //parse using builder to get document representation of the XML file
            Document xmlDocument = documentBuilder.parse("faculty.xml");
            //get the root elememt (list_of_classrooms)
            Element list_of_facultyCourse = xmlDocument.getDocumentElement();
            //retrieve the list of classrooms from the root of the document
            NodeList facultyCourseList = list_of_facultyCourse.getElementsByTagName("faculty");
            //loop through the list of classrooms and create classroom objects            
            for (int i = 0; i < facultyCourseList.getLength(); i++) {
                //get a classroom element from the list
                Element facultyCourseElement = (Element) facultyCourseList.item(i);
                //get the data for the classroom, we retrieve node lists for convenience
                //but we will only have one of each so we will use the first element in 
                // each list
                NodeList courseIDList = facultyCourseElement.getElementsByTagName("courseID");
                
                //create a classroom
                FacultyCourse newFacultyCourse = new FacultyCourse();
                //retrieve the first element from the roomnumber list and get its content (text value)
                String courseID = courseIDList.item(0).getTextContent();
                //set the value in the classroom
                newFacultyCourse.setCourseId(courseID);
                //retrieve the first element from the roomtype list and get its content (text value)
                
                //add the classroom to the data model arraylist
                listOfFacultyCourse.add(newFacultyCourse);
            }
        } // if wrong file name is entered, let Main Menu handle it
        catch (Exception exp) {
            Logger.logError(exp.getMessage());
        } finally {
            return listOfFacultyCourse;
        }
    }
    
    /**
     * Reads a JSON formatted file of classrooms and returns an array list of
     * classrooms.
     *
     */
    public static ArrayList<Faculty> readJSONFile() {

        ArrayList<Faculty> listOfFaculty = new ArrayList<>();

        try {
            // Create input file
            BufferedReader jsonFile = new BufferedReader(new FileReader("faculty.json"));

            // Create JSON object
            Gson gson = new GsonBuilder().create();

            // fromJson returns an array
            Faculty[] facultyArray = gson.fromJson(jsonFile, Faculty[].class);

            // Convert to arraylist for the data model
            for (int i = 0; i < facultyArray.length; i++) {
                listOfFaculty.add(facultyArray[i]);
            }
        } catch (Exception exp) {
            Logger.logError(exp.getMessage());
        } finally {
            return listOfFaculty;
        }
    }
    public static ArrayList<FacultyCourse> readJSONFileFacultyCourse() {

        ArrayList<FacultyCourse> listOfFacultyCourse = new ArrayList<>();

        try {
            // Create input file
            BufferedReader jsonFile = new BufferedReader(new FileReader("faculty.json"));

            // Create JSON object
            Gson gson = new GsonBuilder().create();

            // fromJson returns an array
            FacultyCourse[] facultyCourseArray = gson.fromJson(jsonFile, FacultyCourse[].class);

            // Convert to arraylist for the data model
            for (int i = 0; i < facultyCourseArray.length; i++) {
                listOfFacultyCourse.add(facultyCourseArray[i]);
            }
        } catch (Exception exp) {
            Logger.logError(exp.getMessage());
        } finally {
            return listOfFacultyCourse;
        }
    }
}

