/*
 *  This Class contains lists which will hold objects created in the UI
 *  Anytime you want to store lists of objects created in the UI, add it to
 *  this class.
 */
package utilities;

import baseclasses.Classroom;
import baseclasses.OfferedCourse;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sun.org.apache.xml.internal.serialize.OutputFormat;
import com.sun.org.apache.xml.internal.serialize.XMLSerializer;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import model.OfferedCourseDataModel;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

/**
 * Utility class to read and write Classroom data
 *
 * @author EKRAMER
 */
public class OfferedCourseIO {

    /**
     * Constructor is declared private because the IO classes are utilities
     * which contain static methods
     */
    private OfferedCourseIO() {
    }

    /**
     * Writes out a text file containing all classrooms in the classroom data
     * model
     *
     * The format of the text file is:
     *
     * Example: FA301:CLASSROOM
     */
    public static void writeTextFile(OfferedCourseDataModel offeredCoursedatamodel) {

        PrintWriter textFile = null;

        try {
            // Create output file
            textFile = new PrintWriter("offeredCourse.txt");

            // Loop through the array list of classrooms and print delimited text to a file
            for (OfferedCourse offeredCourse : offeredCoursedatamodel.getListOfOfferedCourses()) {
                textFile.println(offeredCourse.getCourseName() + ":" + offeredCourse.getCourseId() + ":" + offeredCourse.getClassroom());
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        } finally {
            // Flush the output stream and close the file
            textFile.flush();
            textFile.close();
        }
    }

    /**
     * Creates a serialized object output file containing all classrooms in the
     * classroom data model
     */
    public static void writeSerializedFile(OfferedCourseDataModel offeredCoursedatamodel) {
        try {
            // Create output file
            ObjectOutputStream serializedFile = new ObjectOutputStream(
                    new FileOutputStream("offeredCourse.ser"));
            // Write out the data
            serializedFile.writeObject(offeredCoursedatamodel.getListOfOfferedCourses());
        } catch (Exception exp) {
            Logger.logError(exp.getMessage());
        }
    }

    /**
     * Writes out the classroom data in XML format containing all classrooms in
     * the classroom data model
     */
    public static void writeXMLFile(OfferedCourseDataModel offeredCoursedatamodel) {

        // get a document builder factory
        DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();

        try {
            // get a document builder from the factory
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();

            // create an instance of the document model
            Document doc = docBuilder.newDocument();

            // create the root element <list_of_classrooms> and append to document
            Element root = doc.createElement("list_of_OfferedCourses");
            doc.appendChild(root);

            // Loop through the array list of classrooms and create the classroom elements of the xml file
            for (OfferedCourse offeredCourse : offeredCoursedatamodel.getListOfOfferedCourses()) {

                Element offeredCourseElement = doc.createElement("offeredCourse");
                
                Element courseNameElement = doc.createElement("courseName");
                Text courseNameText = doc.createTextNode(offeredCourse.getCourseName().toString());
                courseNameElement.appendChild(courseNameText);
                offeredCourseElement.appendChild(courseNameElement);
                
                Element courseIDElement = doc.createElement("courseID");
                Text courseIDText = doc.createTextNode(offeredCourse.getCourseId().toString());
                courseIDElement.appendChild(courseIDText);
                offeredCourseElement.appendChild(courseIDElement);
                
                Element classroomElement = doc.createElement("classroom");               
                Text classroomText = doc.createTextNode(offeredCourse.getClassroom().toString());
                classroomElement.appendChild(classroomText);
                offeredCourseElement.appendChild(classroomElement);

                root.appendChild(offeredCourseElement);
            }
            // use default xml formatting in the file
            OutputFormat format = new OutputFormat(doc);
            format.setIndenting(true);
            // open the output stream
            XMLSerializer serializer = new XMLSerializer(
                    new FileOutputStream(new File("offeredCourse.xml")), format);
            // write out the object
            serializer.serialize(doc);
        } catch (Exception exp) {
            Logger.logError(exp.getMessage());
        }
    }

    /**
     * Writes out the classroom data in JSON format containing all classrooms in
     * the classroom data model
     *
     */
    public static void writeJSONFile(OfferedCourseDataModel offeredCoursedatamodel) {

        PrintWriter jsonFile = null;

        try {
            // Create output file
            jsonFile = new PrintWriter("offeredCourse.json");

            // Create JSON object
            Gson gson = new GsonBuilder().create();

            // Convert classroom list to JSON format
            gson.toJson(offeredCoursedatamodel.getListOfOfferedCourses(), jsonFile);

        } catch (Exception exp) {
            Logger.logError(exp.getMessage());
        } finally {
            // Flush the output stream and close the file
            jsonFile.flush();
            jsonFile.close();
        }
    }

    /**
     * Reads a set of classroom objects from a serialized file and returns an
     * array list of classrooms
     * @return 
     */
    public static ArrayList<OfferedCourse> readSerializedFile() {

        ArrayList<OfferedCourse> listOfOfferedCourses = new ArrayList<>();

        try {
            ObjectInputStream serializedFile = new ObjectInputStream(
                    new FileInputStream("offeredCourse.ser"));
            // Read the serialized object and cast to its original type
            listOfOfferedCourses = (ArrayList<OfferedCourse>) serializedFile.readObject();
        } catch (Exception exp) {
            Logger.logError(exp.getMessage());
        } finally {
            return listOfOfferedCourses;
        }
    }

    /**
     * Reads a delimited text file of classrooms and returns an array list of
     * classrooms.
     *
     * eof is used to keep track of whether we hit the end of the file, It
     * starts out false and if we hit the end of file (null input), it changes
     * to true and execution stops.
     *
     * The format of the text file is:
     *
     * Example: FA301:CLASSROOM
     */
    public static ArrayList<OfferedCourse> readTextFile() {

        ArrayList<OfferedCourse> listOfOfferedCourses = new ArrayList<>();

        try {
            boolean eof = false;
            BufferedReader textFile = new BufferedReader(new FileReader("offeredCourse.txt"));
            while (!eof) {
                String lineFromFile = textFile.readLine();
                if (lineFromFile == null) {
                    eof = true;
                } else {
                    // Create a classroom
                    OfferedCourse offeredCourse = new OfferedCourse();
                    
                    // Split the input line into classroom elements using the delimiter
                    String[] lineElements = lineFromFile.split(":");

                    // The first element is the classroom number
                    offeredCourse.setCourseName(lineElements[0]);

                    // The second element is the classroom type
                    offeredCourse.setCourseId(lineElements[1]);
                    
                    Classroom classroom = new Classroom();
                    String room = lineElements[2];
                    String type = lineElements[3];
                    classroom.setRoomNumber(room);
                    classroom.setTypeOfRoom(type);                
                    offeredCourse.setClassroom(classroom);
                    
                    // add the classroom to the arraylist
                    listOfOfferedCourses.add(offeredCourse);
                }
            }
        } catch (Exception exp) {
            Logger.logError(exp.getMessage());
        } finally {
            return listOfOfferedCourses;
        }
    }

    /**
     * Reads an XML formatted file of classrooms and returns an array list of
     * classrooms
     */
    public static ArrayList<OfferedCourse> readXMLFile() {

        ArrayList<OfferedCourse> listOfOfferedCourses = new ArrayList<>();

        try {

            // Get the factory instance
            DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();

            //Using factory, get an instance of document builder
            DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();

            //parse using builder to get document representation of the XML file
            Document xmlDocument = documentBuilder.parse("offeredCourse.xml");

            //get the root elememt (list_of_classrooms)
            Element list_of_OfferedCourses = xmlDocument.getDocumentElement();

            //retrieve the list of classrooms from the root of the document
            NodeList offeredCourseList = list_of_OfferedCourses.getElementsByTagName("offeredCourse");

            //loop through the list of classrooms and create classroom objects            
            for (int i = 0; i < offeredCourseList.getLength(); i++) {

                //get a classroom element from the list
                Element offeredCourseElement = (Element) offeredCourseList.item(i);

                //get the data for the classroom, we retrieve node lists for convenience
                //but we will only have one of each so we will use the first element in 
                // each list
                NodeList courseNameList = offeredCourseElement.getElementsByTagName("courseName");
                NodeList courseIDList = offeredCourseElement.getElementsByTagName("courseID");
                NodeList classroomList = offeredCourseElement.getElementsByTagName("classroom");

                //create a classroom
                OfferedCourse newOfferedCourse = new OfferedCourse();

                //retrieve the first element from the roomnumber list and get its content (text value)
                String courseName = courseNameList.item(0).getTextContent();
                //set the value in the classroom
                newOfferedCourse.setCourseName(courseName);

                //retrieve the first element from the roomtype list and get its content (text value)
                String courseID = courseIDList.item(0).getTextContent();
                //compare this string to the values in the RoomType class and set the correct value
                newOfferedCourse.setCourseId(courseID);
                
                
                Classroom classroom = new Classroom();
                String classROOM = classroomList.item(0).getTextContent();
                classroom.setRoomNumber(classROOM);
                classroom.setTypeOfRoom(classROOM);                
                newOfferedCourse.setClassroom(classroom);
                               
                newOfferedCourse.setClassroom(classroom);
                //add the classroom to the data model arraylist
                listOfOfferedCourses.add(newOfferedCourse);
            }
        } // if wrong file name is entered, let Main Menu handle it
        catch (Exception exp) {
            Logger.logError(exp.getMessage());
        } finally {
            return listOfOfferedCourses;
        }
    }

    /**
     * Reads a JSON formatted file of classrooms and returns an array list of
     * classrooms.
     *
     */
    public static ArrayList<OfferedCourse> readJSONFile() {

        ArrayList<OfferedCourse> listOfOfferedCourses = new ArrayList<>();

        try {
            // Create input file
            BufferedReader jsonFile = new BufferedReader(new FileReader("offeredCourse.json"));

            // Create JSON object
            Gson gson = new GsonBuilder().create();

            // fromJson returns an array
            OfferedCourse[] offeredCourseArray = gson.fromJson(jsonFile, OfferedCourse[].class);

            // Convert to arraylist for the data model
            for (int i = 0; i < offeredCourseArray.length; i++) {
                listOfOfferedCourses.add(offeredCourseArray[i]);
            }
        } catch (Exception exp) {
            Logger.logError(exp.getMessage());
        } finally {
            return listOfOfferedCourses;
        }
    }
}
