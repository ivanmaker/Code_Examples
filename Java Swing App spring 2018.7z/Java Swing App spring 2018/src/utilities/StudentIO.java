/*
 *  This Class contains lists which will hold objects created in the UI
 *  Anytime you want to store lists of objects created in the UI, add it to
 *  this class.
 */
package utilities;

import baseclasses.Student;
import baseclasses.StudentCourse;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.sun.org.apache.xml.internal.serialize.OutputFormat;
import com.sun.org.apache.xml.internal.serialize.XMLSerializer;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import model.StudentDataModel;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

/**
 * Utility class to read and write Classroom data
 *
 * @author EKRAMER
 */
public class StudentIO {

    /**
     * Constructor is declared private because the IO classes are utilities
     * which contain static methods
     */
    private StudentIO() {
    }

    /**
     * Writes out a text file containing all classrooms in the classroom data
     * model
     *
     * The format of the text file is:
     *
     * Example: FA301:CLASSROOM
     * @param stduentdatamodel
     */
    public static void writeTextFile(StudentDataModel stduentdatamodel) {

        PrintWriter textFile = null;

        try {
            // Create output file
            textFile = new PrintWriter("student.txt");

            // Loop through the array list of classrooms and print delimited text to a file
            for (Student student : stduentdatamodel.getListOfStudents()) {
                textFile.println(student.getName() + ":" + student.getAddress() + ":" + student.getDateOfBirth() + 
                        ":" + student.getDateOfGraduation() + ":" + student.getCurrentGPA());
            }  
            
            for (StudentCourse studentcourse : stduentdatamodel.getListOfStudentsCourse()) {
                textFile.println(studentcourse.getCourseId() + ":" + studentcourse.getCourseGrades());
            }  
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        } finally {
            // Flush the output stream and close the file
            textFile.flush();
            textFile.close();
        }
    }

    /**
     * Creates a serialized object output file containing all classrooms in the
     * classroom data model
     * @param studentdatamodel
     */
    public static void writeSerializedFile(StudentDataModel studentdatamodel) {
        try {
            // Create output file
            ObjectOutputStream serializedFile = new ObjectOutputStream(
                    new FileOutputStream("student.ser"));
            // Write out the data
            serializedFile.writeObject(studentdatamodel.getListOfStudents());
            serializedFile.writeObject(studentdatamodel.getListOfStudentsCourse());
        } catch (Exception exp) {
            Logger.logError(exp.getMessage());
        }
    }

    /**
     * Writes out the classroom data in XML format containing all classrooms in
     * the classroom data model
     * @param studentdatamodel
     */
    public static void writeXMLFile(StudentDataModel studentdatamodel) {

        // get a document builder factory
        DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();

        try {
            // get a document builder from the factory
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();

            // create an instance of the document model
            Document doc = docBuilder.newDocument();

            // create the root element <list_of_classrooms> and append to document
            Element root = doc.createElement("list_of_students");
            doc.appendChild(root);

            // Loop through the array list of classrooms and create the classroom elements of the xml file
            for (Student student : studentdatamodel.getListOfStudents()) {

                Element studentElement = doc.createElement("student");

                Element nameElement = doc.createElement("name");
                Text nameText = doc.createTextNode(student.getName());
                nameElement.appendChild(nameText);
                studentElement.appendChild(nameElement);

                Element addressElement = doc.createElement("address");
                Text addressText = doc.createTextNode(student.getAddress());
                addressElement.appendChild(addressText);
                studentElement.appendChild(addressElement);
                
                Element dateOfBirthElement = doc.createElement("dateOfBirth");
                SimpleDateFormat birthFormatter=new SimpleDateFormat("yyyy MM dd");   // lowercase "dd"
                dateOfBirthElement.appendChild(doc.createTextNode(birthFormatter.format(
                student.getDateOfBirth().getTime() )));
                studentElement.appendChild(dateOfBirthElement);
                
                Element dateOfGraduationElement = doc.createElement("dateOfGraduation");
                SimpleDateFormat graduationFormatter = new SimpleDateFormat("yyyy MM dd");   // lowercase "dd"
                dateOfGraduationElement.appendChild(doc.createTextNode(graduationFormatter.format(
                student.getDateOfGraduation().getTime() )));
                studentElement.appendChild(dateOfGraduationElement);
               
                Element socialSecurityNumberElement = doc.createElement("socialSecurityNumber");
                Text socialSecurityNumberText = doc.createTextNode(student.getSocialSecurityNumber());
                socialSecurityNumberElement.appendChild(socialSecurityNumberText);
                studentElement.appendChild(socialSecurityNumberElement);
                
                Element currentGPAElement = doc.createElement("currentGPA");
                String GPA = Float.toString(student.getCurrentGPA());
                Text currentGPAText = doc.createTextNode(GPA);
                currentGPAElement.appendChild(currentGPAText);
                studentElement.appendChild(currentGPAElement);
                
                root.appendChild(studentElement);

            }
            
            for (StudentCourse studentCourse : studentdatamodel.getListOfStudentsCourse()) {

                Element studentCourseElement = doc.createElement("studentCourse");
                
                Element courseIDElement = doc.createElement("courseID");
                Text courseIDText = doc.createTextNode(studentCourse.getCourseId());
                courseIDElement.appendChild(courseIDText);
                studentCourseElement.appendChild(courseIDElement);
                
                Element gradesElement = doc.createElement("courseGrades");                         
                String grades = Arrays.toString(studentCourse.getCourseGrades().toArray());
                Text gradesText = doc.createTextNode(grades);
                gradesElement.appendChild(gradesText);
                studentCourseElement.appendChild(gradesElement);
                
                root.appendChild(studentCourseElement);
            }

            // use default xml formatting in the file
            OutputFormat format = new OutputFormat(doc);
            format.setIndenting(true);

            // open the output stream
            XMLSerializer serializer = new XMLSerializer(
                    new FileOutputStream(new File("student.xml")), format);

            // write out the object
            serializer.serialize(doc);

        } catch (Exception exp) {
            Logger.logError(exp.getMessage());
        }
    }

    /**
     * Writes out the classroom data in JSON format containing all classrooms in
     * the classroom data model
     *
     */
    public static void writeJSONFile(StudentDataModel studentdatamodel) {

        PrintWriter jsonFile = null;

        try {
            // Create output file
            jsonFile = new PrintWriter("student.json");

            // Create JSON object
            Gson gson = new GsonBuilder().create();

            // Convert classroom list to JSON format
            gson.toJson(studentdatamodel.getListOfStudents(), jsonFile);
            gson.toJson(studentdatamodel.getListOfStudentsCourse(), jsonFile);

        } catch (Exception exp) {
            Logger.logError(exp.getMessage());
        } finally {
            // Flush the output stream and close the file
            jsonFile.flush();
            jsonFile.close();
        }
    }

    /**
     * Reads a set of classroom objects from a serialized file and returns an
     * array list of classrooms
     */
    public static ArrayList<Student> readSerializedFile() {

        ArrayList<Student> listOfStudents = new ArrayList<>();

        try {
            ObjectInputStream serializedFile = new ObjectInputStream(
                    new FileInputStream("student.ser"));
            // Read the serialized object and cast to its original type
            listOfStudents = (ArrayList<Student>) serializedFile.readObject();
        } catch (Exception exp) {
            Logger.logError(exp.getMessage());
        } finally {
            return listOfStudents;
        }
    }
    
    public static ArrayList<StudentCourse> readSerializedFileStudentCourse() {

        ArrayList<StudentCourse> listOfStudentsCourse = new ArrayList<>();

        try {
            ObjectInputStream serializedFile = new ObjectInputStream(
                    new FileInputStream("student.ser"));
            // Read the serialized object and cast to its original type
            listOfStudentsCourse = (ArrayList<StudentCourse>) serializedFile.readObject();
        } catch (Exception exp) {
            Logger.logError(exp.getMessage());
        } finally {
            return listOfStudentsCourse;
        }
    }

    /**
     * Reads a delimited text file of classrooms and returns an array list of
     * classrooms.
     *
     * eof is used to keep track of whether we hit the end of the file, It
     * starts out false and if we hit the end of file (null input), it changes
     * to true and execution stops.
     *
     * The format of the text file is:
     *
     * Example: FA301:CLASSROOM
     */
    public static ArrayList<Student> readTextFile() {

        ArrayList<Student> listOfStudents = new ArrayList<>();

        try {
            boolean eof = false;
            BufferedReader textFile = new BufferedReader(new FileReader("student.txt"));
            while (!eof) {
                String lineFromFile = textFile.readLine();  
                if (lineFromFile == null) {
                    eof = true;
                } else {
                    // Create a classroom
                    Student student = new Student();
                    // Split the input line into classroom elements using the delimiter
                    String[] lineElements = lineFromFile.split(":");
                    // The first element is the classroom number
                    student.setName(lineElements[0]);
                    // The second element is the classroom type
                    student.setAddress(lineElements[1]);
                    
                    DateFormat df = new SimpleDateFormat("dd MM yyyy");
                    Date DOB = df.parse(lineElements[2]);                  
                    Calendar DOBcal = new GregorianCalendar();
                    DOBcal.setTime(DOB);
                    student.setDateOfBirth((GregorianCalendar) DOBcal);
                    
                    Date DOG = df.parse(lineElements[3]);                  
                    Calendar DOGcal = new GregorianCalendar();
                    DOGcal.setTime(DOG);
                    student.setDateOfGraduation((GregorianCalendar) DOGcal);
                    
                    student.setSocialSecurityNumber(lineElements[4]);
                    
                    float GPA = Float.parseFloat(lineElements[5]);
                    student.setCurrentGPA(GPA);
                    
                    // add the classroom to the arraylist
                    listOfStudents.add(student);
                }
            }
        } catch (Exception exp) {
            Logger.logError(exp.getMessage());
        } finally {
            return listOfStudents;
        }
    }
    
    public static ArrayList<StudentCourse> readTextFileStudentCourse() {

        ArrayList<StudentCourse> listOfStudentsCourse = new ArrayList<>();

        try {
            boolean eof = false;
            BufferedReader textFile = new BufferedReader(new FileReader("student.txt"));
            while (!eof) {
                String lineFromFile = textFile.readLine();  
                if (lineFromFile == null) {
                    eof = true;
                } else {
                    // Create a classroom
                    StudentCourse studentCourse = new StudentCourse();
                    // Split the input line into classroom elements using the delimiter
                    String[] lineElements = lineFromFile.split(":");
                    // The first element is the classroom number
                    studentCourse.setCourseId(lineElements[0]);
                    // The second element is the classroom type
                    int gradesFloat = Integer.parseInt(lineElements[1]);
                    ArrayList<Float> grades = new ArrayList<Float>(gradesFloat);                 
                    studentCourse.setCourseGrades(grades);
                    
                    // add the classroom to the arraylist
                    listOfStudentsCourse.add(studentCourse);
                }
            }
        } catch (Exception exp) {
            Logger.logError(exp.getMessage());
        } finally {
            return listOfStudentsCourse;
        }
    }
    
    /**
     * Reads an XML formatted file of classrooms and returns an array list of
     * classrooms
     */
    public static ArrayList<Student> readXMLFile() {
        ArrayList<Student> listOfStudents = new ArrayList<>();
        try {
            // Get the factory instance
            DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
            //Using factory, get an instance of document builder
            DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
            //parse using builder to get document representation of the XML file
            Document xmlDocument = documentBuilder.parse("student.xml");
            //get the root elememt (list_of_classrooms)
            Element list_of_students = xmlDocument.getDocumentElement();
            //retrieve the list of classrooms from the root of the document
            NodeList studentList = list_of_students.getElementsByTagName("student");

            //loop through the list of classrooms and create classroom objects            
            for (int i = 0; i < studentList.getLength(); i++) {
                //get a classroom element from the list
                Element studentElement = (Element) studentList.item(i);

                //get the data for the classroom, we retrieve node lists for convenience
                //but we will only have one of each so we will use the first element in 
                // each list
                NodeList nameList = studentElement.getElementsByTagName("name");
                NodeList addressList = studentElement.getElementsByTagName("address");
                NodeList DOBList = studentElement.getElementsByTagName("dateOfBirth");
                NodeList DOGList = studentElement.getElementsByTagName("dateOfGratuation");
                NodeList SSNList = studentElement.getElementsByTagName("socialSecurityNumber");
                NodeList GPAList = studentElement.getElementsByTagName("currentGPA");
                
                //create a classroom
                Student newStudent = new Student();
                //retrieve the first element from the roomnumber list and get its content (text value)
                String name = nameList.item(0).getTextContent();
                //set the value in the classroom
                newStudent.setName(name);
                //retrieve the first element from the roomtype list and get its content (text value)
                String address = addressList.item(0).getTextContent();
                //compare this string to the values in the RoomType class and set the correct value
                newStudent.setAddress(address); 
                
                String DOBString = DOBList.item(0).getTextContent();                
                DateFormat df = new SimpleDateFormat("dd MM yyyy");
                Date DOB = df.parse(DOBString);                  
                Calendar DOBcal = new GregorianCalendar();
                DOBcal.setTime(DOB);               
                newStudent.setDateOfBirth((GregorianCalendar) DOBcal);
                
                String DOGString = DOGList.item(0).getTextContent();                                
                Date DOG = df.parse(DOGString);                  
                Calendar DOGcal = new GregorianCalendar();
                DOBcal.setTime(DOG);               
                newStudent.setDateOfGraduation((GregorianCalendar) DOGcal);
                
                String SSN = SSNList.item(0).getTextContent();               
                newStudent.setSocialSecurityNumber(SSN);
                
                String GPA = GPAList.item(0).getTextContent();
                float floatGPA = Float.parseFloat(GPA);                           
                newStudent.setCurrentGPA(floatGPA);
                
                //add the classroom to the data model arraylist
                listOfStudents.add(newStudent);
            }
        } // if wrong file name is entered, let Main Menu handle it
        catch (Exception exp) {
            Logger.logError(exp.getMessage());
        } finally {
            return listOfStudents;
        }
    }
    public static ArrayList<StudentCourse> readXMLFileStudentCourse() {
        ArrayList<StudentCourse> listOfStudentsCourse = new ArrayList<>();
        try {
            // Get the factory instance
            DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
            //Using factory, get an instance of document builder
            DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
            //parse using builder to get document representation of the XML file
            Document xmlDocument = documentBuilder.parse("student.xml");
            //get the root elememt (list_of_classrooms)
            Element list_of_studentsCourse = xmlDocument.getDocumentElement();
            //retrieve the list of classrooms from the root of the document
            NodeList studentCourseList = list_of_studentsCourse.getElementsByTagName("studentCourse");

            //loop through the list of classrooms and create classroom objects            
            for (int i = 0; i < studentCourseList.getLength(); i++) {
                //get a classroom element from the list
                Element studentCourseElement = (Element) studentCourseList.item(i);

                //get the data for the classroom, we retrieve node lists for convenience
                //but we will only have one of each so we will use the first element in 
                // each list
                NodeList courseIDList = studentCourseElement.getElementsByTagName("courseID");
                NodeList courseGradesList = studentCourseElement.getElementsByTagName("courseGrades");
               
                //create a classroom
                StudentCourse newStudentCourse = new StudentCourse();
                //retrieve the first element from the roomnumber list and get its content (text value)
                String courseID = courseIDList.item(0).getTextContent();
                //set the value in the classroom
                newStudentCourse.setCourseId(courseID);
                //retrieve the first element from the roomtype list and get its content (text value)
                String courseGrades = courseGradesList.item(0).getTextContent();
                int gradesFloat = Integer.parseInt(courseGrades);
                ArrayList<Float> grades = new ArrayList<Float>(gradesFloat);               
                //compare this string to the values in the RoomType class and set the correct value
                newStudentCourse.setCourseGrades(grades); 
               
                //add the classroom to the data model arraylist
                listOfStudentsCourse.add(newStudentCourse);
            }
        } // if wrong file name is entered, let Main Menu handle it
        catch (Exception exp) {
            Logger.logError(exp.getMessage());
        } finally {
            return listOfStudentsCourse;
        }
    }

    /**
     * Reads a JSON formatted file of classrooms and returns an array list of
     * classrooms.
     *
     */
    public static ArrayList<Student> readJSONFile() {

        ArrayList<Student> listOfStudents = new ArrayList<>();

        try {
            // Create input file
            BufferedReader jsonFile = new BufferedReader(new FileReader("student.json"));

            // Create JSON object
            Gson gson = new GsonBuilder().create();

            // fromJson returns an array
            Student[] studentArray = gson.fromJson(jsonFile, Student[].class);

            // Convert to arraylist for the data model
            for (int i = 0; i < studentArray.length; i++) {
                listOfStudents.add(studentArray[i]);
            }
        } catch (Exception exp) {
            Logger.logError(exp.getMessage());
        } finally {
            return listOfStudents;
        }
    }
    public static ArrayList<StudentCourse> readJSONFileStudentCourse() {

        ArrayList<StudentCourse> listOfStudentsCourse = new ArrayList<>();

        try {
            // Create input file
            BufferedReader jsonFile = new BufferedReader(new FileReader("student.json"));

            // Create JSON object
            Gson gson = new GsonBuilder().create();

            // fromJson returns an array
            StudentCourse[] studentCourseArray = gson.fromJson(jsonFile, StudentCourse[].class);

            // Convert to arraylist for the data model
            for (int i = 0; i < studentCourseArray.length; i++) {
                listOfStudentsCourse.add(studentCourseArray[i]);
            }
        } catch (Exception exp) {
            Logger.logError(exp.getMessage());
        } finally {
            return listOfStudentsCourse;
        }
    }
}
 